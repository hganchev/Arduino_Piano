Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by Jaz_the_MAN_2 ( https://www.freesound.org/people/Jaz_the_MAN_2/  )
You can find this pack online at: https://www.freesound.org/people/Jaz_the_MAN_2/packs/17749/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 316913__jaz-the-man-2__si.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316913/
    * license: Creative Commons 0
  * 316912__jaz-the-man-2__sol.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316912/
    * license: Creative Commons 0
  * 316911__jaz-the-man-2__sol-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316911/
    * license: Creative Commons 0
  * 316910__jaz-the-man-2__si-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316910/
    * license: Creative Commons 0
  * 316909__jaz-the-man-2__re-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316909/
    * license: Creative Commons 0
  * 316908__jaz-the-man-2__re.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316908/
    * license: Creative Commons 0
  * 316907__jaz-the-man-2__mi-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316907/
    * license: Creative Commons 0
  * 316906__jaz-the-man-2__mi.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316906/
    * license: Creative Commons 0
  * 316905__jaz-the-man-2__fa-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316905/
    * license: Creative Commons 0
  * 316904__jaz-the-man-2__fa.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316904/
    * license: Creative Commons 0
  * 316903__jaz-the-man-2__la-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316903/
    * license: Creative Commons 0
  * 316902__jaz-the-man-2__la.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316902/
    * license: Creative Commons 0
  * 316901__jaz-the-man-2__do-octave.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316901/
    * license: Creative Commons 0
  * 316900__jaz-the-man-2__do-stretched-octave.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316900/
    * license: Creative Commons 0
  * 316899__jaz-the-man-2__do-stretched.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316899/
    * license: Creative Commons 0
  * 316898__jaz-the-man-2__do.wav
    * url: https://www.freesound.org/people/Jaz_the_MAN_2/sounds/316898/
    * license: Creative Commons 0

